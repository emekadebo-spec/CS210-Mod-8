// CS210 Mod 5 Project.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>   // For formatting output
using namespace std;

int main() {
    // Variables for user input
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int numYears;

    // Get user input
    cout << "**********************************" << endl;
    cout << "   Airgead Banking Investment Calculator" << endl;
    cout << "**********************************" << endl;

    cout << "Enter Initial Investment Amount: $";
    cin >> initialInvestment;

    cout << "Enter Monthly Deposit: $";
    cin >> monthlyDeposit;

    cout << "Enter Annual Interest Rate (percent): ";
    cin >> annualInterest;

    cout << "Enter Number of Years: ";
    cin >> numYears;

    cout << "**********************************" << endl;
    cout << "Press any key to continue . . ." << endl;
    cin.ignore(); // Clear input buffer
    cin.get();    // Wait for user to press a key

    // Set up formatting for dollar amounts
    cout << fixed << setprecision(2);

    int months = numYears * 12;

    //-----------------------------
    // Report 1: Without Monthly Deposits
    //-----------------------------
    cout << endl;
    cout << "   Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "====================================================================" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
    cout << "--------------------------------------------------------------------" << endl;

    double totalAmount = initialInvestment;

    for (int year = 1; year <= numYears; year++) {
        double interestEarned = 0.0;

        for (int month = 1; month <= 12; month++) {
            double monthlyInterest = totalAmount * ((annualInterest / 100) / 12);
            interestEarned += monthlyInterest;
            totalAmount += monthlyInterest;
        }

        cout << year << "\t$" << totalAmount << "\t\t\t$" << interestEarned << endl;
    }

    //-----------------------------
    // Report 2: With Monthly Deposits
    //-----------------------------
    cout << endl;
    cout << "   Balance and Interest With Additional Monthly Deposits" << endl;
    cout << "====================================================================" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;
    cout << "--------------------------------------------------------------------" << endl;

    totalAmount = initialInvestment;

    for (int year = 1; year <= numYears; year++) {
        double interestEarned = 0.0;

        for (int month = 1; month <= 12; month++) {
            totalAmount += monthlyDeposit; // Add deposit first
            double monthlyInterest = totalAmount * ((annualInterest / 100) / 12);
            interestEarned += monthlyInterest;
            totalAmount += monthlyInterest;
        }

        cout << year << "\t$" << totalAmount << "\t\t\t$" << interestEarned << endl;
    }

    return 0;
}
